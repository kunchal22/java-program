package Camera3;

import java.util.ArrayList;
import java.util.List;

public class CameraRepository {
    private List<Camera> cameras;

    public CameraRepository() {
        cameras = new ArrayList<>();
    }

    public void addCamera(Camera camera) {
        cameras.add(camera);
    }

    public void removeCamera(int id) {
        cameras.removeIf(camera -> camera.getId() == id);
    }

    public List<Camera> getAllCameras() {
        return cameras;
    }

    public List<Camera> getAvailableCameras() {
        List<Camera> availableCameras = new ArrayList<>();

        for (Camera camera : cameras) {
            if (!camera.isRented()) {
                availableCameras.add(camera);
            }
        }

        return availableCameras;
    }

	public Camera getCameraById(int id) {
        	for (Camera camera : cameras) {
                    if (camera.getId() == id) {
                        return camera;
                    }
            }
        	return null;
	}
}
