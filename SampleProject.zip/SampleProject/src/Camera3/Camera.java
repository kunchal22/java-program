package Camera3;

public class Camera {
    private int id;
    private String name;
    private String description;
    private boolean isRented;
	private double price;

    public Camera(int id, String name, String description, double price, boolean isRented) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.isRented = isRented;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public boolean isRented() {
        return isRented;
    }

    public void setRented(boolean rented) {
        isRented = rented;
    }

	public double getPrice() {
		// TODO Auto-generated method stub
		return price;
	}
}
class User {
    private String username;
    private String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}