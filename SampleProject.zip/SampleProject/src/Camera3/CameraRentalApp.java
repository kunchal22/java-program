package Camera3;

import java.util.Scanner;

public class CameraRentalApp {
    private static Scanner scanner = new Scanner(System.in);
    
    private static CameraRepository cameraRepository = new CameraRepository();
    private static String username;
    private static String password;
    public static void main(String[] args) {
    	boolean isLoggedIn = false;
    	
       

        
            System.out.println("\nWelcome to the Camera Rental App");
            do {
            System.out.println("Enter your Username:");
            username=scanner.nextLine();
            if (username.equalsIgnoreCase("exit")) {
                System.out.println("Goodbye!");
                return;
            }
            System.out.println("Enter your Password:");
            password=scanner.nextLine();
            isLoggedIn = login1();

            if (!isLoggedIn) {
                System.out.println("Invalid username or password. Please try again.");
            }
        } while (!isLoggedIn);
            ShowMainMenu();}

            private static void ShowMainMenu() {
            	 int choice;

                 do {
                     System.out.println("\nCamera Rental App");
                     System.out.println("1. Add a camera");
                     System.out.println("2. Remove a camera");
                     System.out.println("3. List all cameras");
                     System.out.println("4. List available cameras");
                     System.out.println("5. Rent a camera");
                     System.out.println("6. Exit");
                     System.out.print("Enter your choice: ");

                     choice = scanner.nextInt();
                     scanner.nextLine();

                     switch (choice) {
                         case 1:
                             addCamera();
                             break;
                         case 2:
                             removeCamera();
                             break;
                         case 3:
                             listAllCameras();
                             break;
                         case 4:
                             listAvailableCameras();
                             break;
                         case 5:
                             rentCamera();
                             break;
                         case 6:
                             System.out.println("Goodbye!");
                             break;
                         default:
                             System.out.println("Invalid choice");
                             break;
                     }
                 } while (choice != 6);
             }
		
	
			private static boolean login1() {
            	return username.equals("anchal")&& password.equals("kunchal22");
            }
      

	private static void addCamera() {
        System.out.print("Enter camera ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter camera name: ");
        String name = scanner.nextLine();
        System.out.print("Enter camera description: ");
        String description = scanner.nextLine();
        System.out.print("Enter camera price: ");
        double price = scanner.nextDouble();

        Camera camera = new Camera(id, name, description, price, false);
        cameraRepository.addCamera(camera);
        System.out.println("Camera added successfully");
    }

    private static void removeCamera() {
        System.out.print("Enter camera ID to remove: ");
        int id = scanner.nextInt();

        cameraRepository.removeCamera(id);
        System.out.println("Camera removed successfully");
    }

    private static void listAllCameras() {
        System.out.println("List of all cameras:");

        for (Camera camera : cameraRepository.getAllCameras()) {
            System.out.println("ID: " + camera.getId() + ", Name: " + camera.getName() +
                    ", Description: " + camera.getDescription() + ", Price: " + camera.getName() +
                    ", Is rented: " + camera.isRented());
        }
    }

    private static void listAvailableCameras() {
        System.out.println("List of available cameras:");

        for (Camera camera : cameraRepository.getAvailableCameras()) {
            System.out.println("ID: " + camera.getId() + ", Name: " + camera.getId() +
                    ", Description: " + camera.getDescription() + ", Price: " + camera.getPrice());
        }
    }

    private static void rentCamera() {
        System.out.print("Enter camera ID to rent: ");
        int id = scanner.nextInt();

        Camera camera = cameraRepository.getCameraById(id);

        if (camera == null) {
            System.out.println("Camera not found");
        } else if (camera.isRented()) {
            System.out.println("Camera is already rented");
        } else {
            camera.setRented(true);
            System.out.println("Camera rented successfully");
        }
    }
}