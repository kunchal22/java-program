package Camera2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CameraRentalSystem {
   private List<Camera> cameras;
   private List<Rental> rentals;

   public CameraRentalSystem() {
      cameras = new ArrayList<>();
      rentals = new ArrayList<>();
   }

   public void addCamera(Camera camera) {
      cameras.add(camera);
   }
   
   public void removeCamera(Camera camera) {
      cameras.remove(camera);
   }
   
   public void viewMyCameras() {
      System.out.println("My Cameras:");
      for (Camera camera : cameras) {
         System.out.println(camera.getCameraType());
      }
   }

   public Camera selectCamera() {
      Scanner scanner = new Scanner(System.in);
      System.out.println("Select a camera type:");
      for (int i = 0; i < cameras.size(); i++) {
         System.out.println((i + 1) + ". " + cameras.get(i).getCameraType());
      }
      int selection = scanner.nextInt();
      return cameras.get(selection - 1);
   }

   public int getRentalDuration() {
      Scanner scanner = new Scanner(System.in);
      System.out.println("Enter rental duration (in days):");
      return scanner.nextInt();
   }

   public void rentCamera() {
      Camera selectedCamera = selectCamera();
      int rentalDuration = getRentalDuration();
      Rental rental = new Rental(selectedCamera, rentalDuration);
      double rentalCost = rental.calculateRentalCost();
      System.out.println("Rental Details:");
      System.out.println("Camera Type: " + selectedCamera.getCameraType());
      System.out.println("Rental Duration: " + rentalDuration + " days");
      System.out.println("Rental Cost: $" + rentalCost);
      System.out.println("Confirm rental? (Y/N)");
      Scanner scanner = new Scanner(System.in);
      String confirmation = scanner.nextLine();
      if (confirmation.equalsIgnoreCase("Y")) {
         rental.setRentalStatus(RentalStatus.RENTED);
         rentals.add(rental);
         System.out.println("Thank you for your rental!");
      } else {
         System.out.println("Rental cancelled.");
      }
   }

public static void main(String[] args) {
      CameraRentalSystem rentalSystem = new CameraRentalSystem();

      Scanner scanner = new Scanner(System.in);
      while (true) {
         System.out.println("Select an option:");
         System.out.println("1. Add a camera");
         System.out.println("2. Remove a camera");
         System.out.println("3. View my cameras");
         System.out.println("4. Rent a camera");
         System.out.println("5. Exit");
         int selection = scanner.nextInt();
         switch (selection) {
            case 1:
               System.out.println("Enter camera brand:");
               String brand = scanner.next();
               System.out.println("Enter camera model:");
               String model = scanner.next();
               System.out.println("Enter rental price per day:");
               double rentalPrice = scanner.nextDouble();
               Camera camera = new Camera(brand, model, rentalPrice);
               rentalSystem.addCamera(camera);
               System.out.println("New camera added: " + camera.getCameraType());
               break;
            case 2:
               Camera cameraToRemove = rentalSystem.selectCamera();
               rentalSystem.removeCamera(cameraToRemove);
               System.out.println("Camera removed: " + cameraToRemove.getCameraType());
               break;
            case 3:
               rentalSystem.viewMyCameras();
               break;
            case 4:
               rentalSystem.rentCamera();
               break;
            case 5:
               System.exit(0);
            default:
               System.out.println("Invalid selection. Please try again.")
         }
      }
   }