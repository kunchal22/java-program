package Camera;

import java.time.LocalDate;

public class Rental {
   private Camera camera;
   private LocalDate startDate;
   private LocalDate endDate;
   private double rentalCost;

   // Constructor
   public Rental(Camera camera, LocalDate startDate, LocalDate endDate, double rentalCost) {
      this.camera = camera;
      this.startDate = startDate;
      this.endDate = endDate;
      this.rentalCost = rentalCost;
   }

   // Getters and setters
   public Camera getCamera() {
      return camera;
   }

   public void setCamera(Camera camera) {
      this.camera = camera;
   }

   public LocalDate getStartDate() {
      return startDate;
   }

   public void setStartDate(LocalDate startDate) {
      this.startDate = startDate;
   }

   public LocalDate getEndDate() {
      return endDate;
   }

   public void setEndDate(LocalDate endDate) {
      this.endDate = endDate;
   }

   public double getRentalCost() {
      return rentalCost;
   }

   public void setRentalCost(double rentalCost) {
      this.rentalCost = rentalCost;
   }

   // toString method
   public String toString() {
      return "Rental: " + camera.getBrand() + " " + camera.getModel() + " (" + camera.getType() + ")" + ", Start Date: " + startDate + ", End Date: " + endDate + ", Rental Cost: $" + rentalCost;
   }
}