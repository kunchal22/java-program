package Camera;

import java.time.LocalDate;

public class Main {
   public static void main(String[] args) {
      // Create rental manager object
      RentalManager rentalManager = new RentalManager();

      // Create cameras
      Camera camera1 = new Camera("A7 III", "Sony", "Mirrorless", 50.0, true);
      Camera camera2 = new Camera("EOS R5", "Canon", "Mirrorless", 80.0, true);
      Camera camera3 = new Camera("Z6 II", "Nikon", "Mirrorless", 60.0, true);
      Camera camera4 = new Camera("D850", "Nikon", "DSLR", 70.0, true);

      // Add cameras to rental manager
      rentalManager.addCamera(camera1);
      rentalManager.addCamera(camera2);
      rentalManager.addCamera(camera3);
      rentalManager.addCamera(camera4);

      // Rent a camera
      LocalDate startDate = LocalDate.of(2023, 5, 15);
      LocalDate endDate = LocalDate.of(2023, 5, 17);
      boolean success = rentalManager.rentCamera(camera1, startDate, endDate);
      if (success) {
         System.out.println("Camera rented successfully!");
      } else {
         System.out.println("Camera is not available for rental.");
      }

      // Return a camera
      success = rentalManager.returnCamera(camera1);
      if (success) {
         System.out.println("Camera returned successfully!");
      } else {
         System.out.println("Camera cannot be returned yet.");
      }

      // Display active rentals
      System.out.println("Active rentals:");
      for (Rental rental : rentalManager.getActiveRentals()) {
         System.out.println(rental.toString());
      }

      // Display available cameras
      System.out.println("Available cameras:");
      for (Camera camera : rentalManager.getAvailableCameras()) {
         System.out.println(camera.toString());
      }
   }
}