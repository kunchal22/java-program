package Camera;

public class Camera {
	   private String model;
	   private String brand;
	   private String type;
	   private double rentalPrice;
	   private boolean available;

	   // Constructor
	   public Camera(String model, String brand, String type, double rentalPrice, boolean available) {
	      this.model = model;
	      this.brand = brand;
	      this.type = type;
	      this.rentalPrice = rentalPrice;
	      this.available = available;
	   }

	   // Getters and setters
	   public String getModel() {
	      return model;
	   }

	   public void setModel(String model) {
	      this.model = model;
	   }

	   public String getBrand() {
	      return brand;
	   }

	   public void setBrand(String brand) {
	      this.brand = brand;
	   }

	   public String getType() {
	      return type;
	   }

	   public void setType(String type) {
	      this.type = type;
	   }

	   public double getRentalPrice() {
	      return rentalPrice;
	   }

	   public void setRentalPrice(double rentalPrice) {
	      this.rentalPrice = rentalPrice;
	   }

	   public boolean isAvailable() {
	      return available;
	   }

	   public void setAvailable(boolean available) {
	      this.available = available;
	   }

	   // toString method
	   public String toString() {
	      return "Camera: " + brand + " " + model + " (" + type + ")" + ", Rental Price: $" + rentalPrice + " per day, Available: " + available;
	   }
	}