package FirstPackage;
public class MyThread extends Thread {

    public void run() {
        System.out.println("Thread is running!");
    }

	public void start() {
		// TODO Auto-generated method stub
		
	}
    
}

  class ThreadDemo{
    
    public static void main(String[] args) {
        
        MyThread mt = new MyThread();
        mt.start();
        
    }
    
}