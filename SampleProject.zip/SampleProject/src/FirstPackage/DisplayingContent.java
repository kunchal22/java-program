package FirstPackage;
import java.util.Scanner;
public class DisplayingContent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// factorial
		//Declaring variable 
		int no;
		int fact_var=1;
		// Creating Scanner object

		Scanner sc=new Scanner(System.in);
		//reading input from user
		
System.out.println("Enter a no.");
no=sc.nextInt();
//Calculating Factorial
//for(int i=1;i<=no;i++) {
	//fact_var=fact_var*i;
//}
int i=1;//initial value
while(i<=no) {//terminating condition
	fact_var *=i;//fact_var=fact_var*i
	i++;//i=i+1//increment or step value
}
//displaying factorial
System.out.println("Factorial of a no:" + fact_var);

	}

}
