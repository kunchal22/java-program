package FirstPackage;

class AccessModifiersDemo {
    public int publicVar = 00;
    private int privateVar = 20;
    protected int protectedVar = 4130;

    public void publicMethod() {
        System.out.println("This is a public method");
    }

    private void privateMethod() {
        System.out.println("This is a private method");
    }

    protected void protectedMethod() {
        System.out.println("This is a protected method");
    }

    void defaultMethod() {
        System.out.println("This is a default method");
    }
}

public class Main {
    public static void main(String[] args) {
        AccessModifiersDemo obj = new AccessModifiersDemo();

        // accessing public variable and method
        System.out.println("publicVar = " + obj.publicVar);
        obj.publicMethod();

        // accessing private variable and method (will cause a compile error)
        //System.out.println("privateVar = " + obj.privateVar);
        //obj.privateMethod();

        // accessing protected variable and method
        System.out.println("publicVar = " + obj.publicVar);
        obj.protectedMethod();

        // accessing default method
        obj.defaultMethod();
    }
}
