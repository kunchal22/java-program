package FirstPackage;

import java.util.Scanner;

public class Calculator {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter the first number: ");
        double n1 = input.nextDouble();
        
        System.out.print("Enter the second number: ");
        double n2 = input.nextDouble();
        
        System.out.println("Select an operation (+, -, *, /,%): ");
        char operator = input.next().charAt(0);
        
        double result = 0;
        switch(operator) {
            case '+':
                result = n1 + n2;
                break;
                
            case '-':
                result = n1 - n2;
                break;
                
            case '*':
                result = n1 * n2;
                break;
                
            case '/':
                result = n1 / n2;
                break;
                
            case '%':
                result = n1 % n2;
                break;

                
            default:
                System.out.println("Invalid operator!");
                return;
        }
        
        System.out.println(n1 + " " + operator + " " + n2 + " = " + result);
    }
}
