package FirstPackage;
import java.util.HashMap;

public class MapDemo {
    public class Entry<T1, T2> {

		public int getValue() {
			// TODO Auto-generated method stub
			return 0;
		}

	}

	public static void main(String[] args) {
        // creating and adding elements to a HashMap
        HashMap<String, Integer> map = new HashMap<>();
        map.put("Dog", 7);
        map.put("Cat", 9);
        map.put("Rat", 3);

        // iterating over the HashMap using entrySet method
        System.out.println("HashMap:");
        for (java.util.Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue());
        }

        // checking if a key exists in the HashMap
        String key = "Dog";
        if (map.containsKey(key)) {
            System.out.println("The key '" + key + "' exists in the map with value " + map.get(key));
        } else {
            System.out.println("The key '" + key + "' does not exist in the map");
        }
    }
}



