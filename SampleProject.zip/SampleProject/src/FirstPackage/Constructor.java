package FirstPackage;

public class Constructor {
	private String name;
    private int P_Number;

    // default constructor
    public Constructor() {
        this.name = "Alexa";
        this.P_Number = 789090893;
    }

    // parameterized constructor
    public Constructor(String name, int P_Number) {
        this.name = name;
        this.P_Number = P_Number;
    }

    // copy constructor
    public Constructor(Constructor obj) {
        this.name = obj.name;
        this.P_Number = obj.P_Number;
    }

    public static void main(String[] args) {
        // creating objects using different constructors
        Constructor obj1 = new Constructor();
        Constructor obj2 = new Constructor("Smith",987090993);
        Constructor obj3 = new Constructor(obj1);

        // printing object properties
        System.out.println("Name: " + obj1.name + ", P_Number: " + obj1.P_Number);
        System.out.println("Name: " + obj2.name + ", P_Number: " + obj2.P_Number);
        System.out.println("Name: " + obj3.name + ", P_Number: " + obj3.P_Number);
    }
}


