package FirstPackage;



public class StringDemo {
    public static void main(String[] args) {
        // creating a string
        String str = "Welcome ,Hello, world!";

        // converting the string to a StringBuffer
        StringBuffer stringBuffer = new StringBuffer(str);

        // appending some text to the StringBuffer
        stringBuffer.append(" This is a StringBuffer.");

        // converting the StringBuffer back to a string
        String newStr1 = stringBuffer.toString();

        // converting the string to a StringBuilder
        StringBuilder stringBuilder = new StringBuilder(str);

        // appending some text to the StringBuilder
        stringBuilder.append(" This is a StringBuilder.");

        // converting the StringBuilder back to a string
        String newStr2 = stringBuilder.toString();

        // printing the original string and the new strings
        System.out.println("Original string: " + str);
        System.out.println("String converted to StringBuffer: " + newStr1);
        System.out.println("String converted to StringBuilder: " + newStr2);
    }
}
