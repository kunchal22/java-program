package FirstPackage;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailValidator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // prompt the user to enter an email address
        System.out.print("Enter an email address: ");
        String email = sc.nextLine();

        // define the regular expression pattern for a valid email address
        Pattern pattern = Pattern.compile("^[a-zA-Z0-9_+&*-]+(?:\\." +
                "[a-zA-Z0-9_+&-]+)@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,}$");

        // validate the email address using the pattern
        Matcher matcher = pattern.matcher(email);
        if (matcher.matches()) {
            System.out.println(email + " is a valid email address");
        } else {
            System.out.println(email + " is not a valid email address");
        }

        sc.close();
    }
}
