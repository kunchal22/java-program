package FirstPackage;
import java.time.LocalDate;

public class Rental {
    private Camera camera;
    private User user;
    private LocalDate startDate;
    private LocalDate endDate;

    public Rental(Camera camera, User user, LocalDate startDate, LocalDate endDate) {
        this.camera = camera;
        this.user = user;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public Camera getCamera() {
        return camera;
    }

    public User getUser() {
        return user;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public double calculateRentalCost() {
        long days = ChronoUnit.DAYS.between(startDate, endDate);
        return days * camera.getRentalPrice();
    }
}
