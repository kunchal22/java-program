package FirstPackage;
import java.time.LocalDate;


public class CameraRentalApp {
    public static void main(String[] args) {
        User user = new User("John Doe", "johndoe@example.com", "password123");
        Camera camera = new Camera("Nikon", "D850", 50.0);
        RentalManager rentalManager = new RentalManager();
        rentalManager.rentCamera(camera, user, LocalDate.now(), LocalDate.now().plusDays(3));
        for (Rental rental : rentalManager.getRentals()) {
            System.out.println("User: " + rental.getUser());
            	}
        	}
        }
            		
            		
//public class CameraRentalApp {
//    private static final String CameraDatabase = null;
//	private static Scanner scanner = new Scanner(System.in);
//    private static RentalManager rentalManager = new RentalManager();
//
//    public static void main(String[] args) {
//        int choice = -1;
//        while (choice != 0) {
//            System.out.println("Welcome to the Camera Rental App!");
//            System.out.println("1. Rent a Camera");
//            System.out.println("2. View Rentals");
//            System.out.println("0. Exit");
//            System.out.print("Enter your choice: ");
//            choice = scanner.nextInt();
//            switch (choice) {
//                case 1:
//                    rentCamera();
//                    break;
//                case 2:
//                    viewRentals();
//                    break;
//                case 0:
//                    System.out.println("Goodbye!");
//                    break;
//                default:
//                    System.out.println("Invalid choice. Please try again.");
//                    break;
//            }
//            System.out.println();
//        }
//    }
//
//    private static void rentCamera() {
//        System.out.println("Available Cameras:");
//        List<Camera> cameras = CameraDatabase.getAvailableCameras();
//        for (int i = 0; i < cameras.size(); i++) {
//            System.out.println((i + 1) + ". " + cameras.get(i));
//        }
//        System.out.print("Enter the camera number you want to rent: ");
//        int cameraNumber = scanner.nextInt();
//        if (cameraNumber < 1 || cameraNumber > cameras.size()) {
//            System.out.println("Invalid camera number. Please try again.");
//            return;
//        }
//        Camera camera = cameras.get(cameraNumber - 1);
//        System.out.print("Enter your name: ");
//        scanner.nextLine();
//        String name = scanner.nextLine();
//        System.out.print("Enter your email address: ");
//        String email = scanner.nextLine();
//        System.out.print("Enter the rental start date (YYYY-MM-DD): ");
//        String startDateString = scanner.nextLine();
//        LocalDate startDate = LocalDate.parse(startDateString);
//        System.out.print("Enter the rental end date (YYYY-MM-DD): ");
//        String endDateString = scanner.nextLine();
//        LocalDate endDate = LocalDate.parse(endDateString);
//        User user = new User(name, email);
//        rentalManager.rentCamera(camera, user, startDate, endDate);
//        System.out.println("Thank you for renting a " + camera.getBrand() + " " + camera.getModel() + "!");
//    }
//
//    private static void viewRentals() {
//        List<Rental> rentals = rentalManager.getRentals();
//        if (rentals.isEmpty()) {
//            System.out.println("No rentals found.");
//        } else {
//            System.out.println("Rentals:");
//            for (Rental rental : rentals) {
//                System.out.println(rental);
//            }
//        }
//    }
//}