package FirstPackage;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class OperatorsTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
