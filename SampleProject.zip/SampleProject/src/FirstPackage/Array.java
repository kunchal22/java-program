package FirstPackage;

public class Array {
    public static void main(String[] args) {
        // declaring an array of integers
        int[] numbers = new int[6];

        // initializing the array
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = i + 1;
        }

        // accessing elements of the array
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("numbers[" + i + "] = " + numbers[i]);
        }

        // declaring and initializing an array of strings
        String[] names = {"Alexa", "Sovin", "Boby"};

        // accessing elements of the array
        for (int i = 0; i < names.length; i++) {
            System.out.println("names[" + i + "] = " + names[i]);
        }

        // multi-dimensional array
        int[][] matrix = {{34, 22,33}, {31, 14,12}, {15, 36,55}};

        // accessing elements of the array
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.println("matrix[" + i + "][" + j + "] = " + matrix[i][j]);
            }
        }
    }
}


