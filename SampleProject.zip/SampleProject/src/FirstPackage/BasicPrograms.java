package FirstPackage;

public class BasicPrograms {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int no1=10,no2=20;
System.out.println("Airthmetic Operations");
System.out.println("Addition" +(no1+no2));


	}

}
