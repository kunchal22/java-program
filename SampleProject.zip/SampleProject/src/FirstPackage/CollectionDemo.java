package FirstPackage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;


public class CollectionDemo {
    public static void main(String[] args) {
        // creating and adding elements to an ArrayList
        ArrayList<String> list = new ArrayList<>();
        list.add("Volvo");
        list.add("Maruti");
        list.add("Honda");

        // iterating over the ArrayList using for-each loop
        System.out.println("ArrayList:");
        for (String item : list) {
            System.out.println(item);
        }

        // creating and adding elements to a HashSet
        HashSet<Integer> set = new HashSet<>();
        set.add(10);
        set.add(20);
        set.add(30);
        set.add(10); // adding a duplicate element

        // iterating over the HashSet using forEach method
        System.out.println("HashSet:");
        set.forEach(item -> System.out.println(item));

        // creating and adding elements to a HashMap
        HashMap<String, Integer> map = new HashMap<>();
        map.put("Volvo", 1);
        map.put("Maruti", 2);
        map.put("Honda", 3);

        // iterating over the HashMap using forEach method
        System.out.println("HashMap:");
        map.forEach((key, value) -> System.out.println(key + " -> " + value));
    }


}
