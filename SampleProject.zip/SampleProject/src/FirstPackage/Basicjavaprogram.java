package FirstPackage;
import java.util.Scanner;

public class Basicjavaprogram {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int no1=10,no2=20;
Scanner sc =new Scanner(System.in);
System.out.println("Enter frst no.");
no1=sc.nextInt();
System.out.println("Enter second no.");
no2=sc.nextInt();
System.out.println("Airthmetic Operations");
System.out.println("Addition" +(no1+no2));

}
}
