package FirstPackage;
import java.util.regex.*;

public class RegexDemo {
    public static void main(String[] args) {
        // creating a regular expression pattern
        Pattern pattern = Pattern.compile("\\d+");

        // creating a matcher object
        Matcher matcher = pattern.matcher("5567 abc 2345 def");

        // finding the first match
        if (matcher.find()) {
            System.out.println("Found match: " + matcher.group());
        }

        // finding all matches
        matcher.reset();
        while (matcher.find()) {
            System.out.println("Found match: " + matcher.group());
        }

        // replacing matches
        String newStr = matcher.replaceAll("N");
        System.out.println("After replacement: " + newStr);
    }
}