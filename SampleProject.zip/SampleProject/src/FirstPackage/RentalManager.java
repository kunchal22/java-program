package FirstPackage;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class RentalManager {
   private List<Camera> cameras;
   private List<Rental> rentals;

   // Constructor
   public RentalManager() {
      cameras = new ArrayList<>();
      rentals = new ArrayList<>();
   }

   // Add camera method
   public void addCamera(Camera camera) {
      cameras.add(camera);
   }

   // Remove camera method
   public void removeCamera(Camera camera) {
      cameras.remove(camera);
   }

   // Rent camera method
   public boolean rentCamera(Camera camera, LocalDate startDate, LocalDate endDate) {
      if (camera.isAvailable()) {
         double rentalCost = camera.getRentalPrice() * ((endDate.toEpochDay() - startDate.toEpochDay()) + 1);
         Rental rental = new Rental(camera, startDate, endDate, rentalCost);
         rentals.add(rental);
         camera.setAvailable(false);
         return true;
      } else {
         return false;
      }
   }

   // Return camera method
   public boolean returnCamera(Camera camera) {
      for (Rental rental : rentals) {
         if (rental.getCamera() == camera && rental.getEndDate().isBefore(LocalDate.now())) {
            rentals.remove(rental);
            camera.setAvailable(true);
            return true;
         }
      }
      return false;
   }

   // Get all rentals method
   public List<Rental> getAllRentals() {
      return rentals;
   }

   // Get active rentals method
   public List<Rental> getActiveRentals() {
      List<Rental> activeRentals = new ArrayList<>();
      for (Rental rental : rentals) {
         if (rental.getEndDate().isAfter(LocalDate.now())) {
            activeRentals.add(rental);
         }
      }
      return activeRentals;
   }

   // Get available cameras method
   public List<Camera> getAvailableCameras() {
      List<Camera> availableCameras = new ArrayList<>();
      for (Camera camera : cameras) {
         if (camera.isAvailable()) {
            availableCameras.add(camera);
         }
      }
      return availableCameras;
   }
}