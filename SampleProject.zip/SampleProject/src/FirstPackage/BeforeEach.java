package FirstPackage;

public @interface BeforeEach {

}
