package FirstPackage;

public class SimpleCallingamethodproject {
	public static void main(String[] args) {
        // calling a method from within the same class
        int sum = add(665650, 10003);
        System.out.println("The sum  is: " + sum);

       
		// calling a method from a different class
        int modulus = solve.modulus1(2098, 3);
        System.out.println("The modulus is: " + modulus);
    }

    // method to add two integers and return the sum
    public static int add(int a, int b) {
        return a + b;
    }
}

class solve{
    // method to find the modulus of two number
    public static int modulus1(int a, int b) {
        return a % b;
    }

	public static int modulus(int i, int j) {
		// TODO Auto-generated method stub
		return 0;
	}
}
