/**
 * 
 */
/**
 * @author pc
 *
 */
module SampleProject {
	requires java.base;
}