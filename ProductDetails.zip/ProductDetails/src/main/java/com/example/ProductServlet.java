package com.example;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import jakarta.servlet.http.HttpServletResponse;

public class ProductServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String name = request.getParameter("name");
        String price = request.getParameter("price");
        String description = request.getParameter("description");
        
        // Process the data (you can store it in a database or perform any other operation)
        // For demonstration purposes, we will simply store the data as request attributes
        request.setAttribute("productName", name);
        request.setAttribute("productPrice", price);
        request.setAttribute("productDescription", description);
        
        // Forward the request to a JSP for displaying the entered data
        request.getRequestDispatcher("productDetails.jsp").forward(request, response);
    }
}