package com.simpli;

class Multi3 implements Runnable{  
public void run(){  
System.out.println("thread is running...");  
}  
  
public static void main(String args[]){  
Multi3 m1=new Multi3();  
Thread t =new Thread(m1);   // Using the constructor Thread(Runnable r)  
t.start();  
 }  
}

