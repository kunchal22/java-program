package com.simpli;

public class throw1{
	  static void checkAge(int age) {
	    if (age < 21) {
	      throw new ArithmeticException("Access denied - You must be at least 21 years old.");
	    }
	    else {
	      System.out.println("Access granted - You are old enough!");
	    }
	  }

	  public static void main(String[] args) {
	    checkAge(18); // Set age to 18 (which is below 21...)
	  }
	}
