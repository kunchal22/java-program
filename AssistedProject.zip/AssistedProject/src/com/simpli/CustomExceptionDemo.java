package com.simpli;

	class MyException extends Exception {
	    public MyException(String message) {
	        super(message);
	    }
	}

	public class CustomExceptionDemo {
	    public static void main(String[] args) {
	        try {
	            int x = 95;
	            int y = 0;
	            if (y == 0) {
	                throw new MyException("Divide by zero error.");
	            }
	            int result = x / y;
	            System.out.println("Result: " + result);
	        } catch (MyException e) {
	            System.out.println("An error occurred: " + e.getMessage());
	        }
	    }
	

}
