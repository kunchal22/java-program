package com.simpli;

class Person {
    private String name;
    private int age;
 
    public String getName() { return name; }
 
    public void setName(String name) { this.name = name; }
 
    public int getAge() { return age; }
 
    public void setAge(int age) { this.age = age; }
}
 
public class Main2 {
    public static void main(String[] args)
    {
        Person person = new Person();
        person.setName("Alexa");
        person.setAge(10);
 
        System.out.println("Name: " + person.getName());
        System.out.println("Age: " + person.getAge());
    }
}
