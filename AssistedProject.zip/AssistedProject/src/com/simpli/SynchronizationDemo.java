package com.simpli;

public class SynchronizationDemo {
    
    public static void main(String[] args) {
        
        BankAccount account = new BankAccount();
        
        // Create two threads that withdraw money from the account
        Thread t1 = new Thread(new WithdrawRunnable(account));
        Thread t2 = new Thread(new WithdrawRunnable(account));
        
        // Start both threads
        t1.start();
        t2.start();
        
    }
    
    private static class BankAccount {
        private int balance = 1000;
        
        public synchronized void withdraw(int amount) {
            if (balance >= amount) {
                balance -= amount;
                System.out.println(Thread.currentThread().getName() + " withdrew $" + amount);
            } else {
                System.out.println(Thread.currentThread().getName() + " tried to withdraw $" + amount + ", but there isn't enough balance!");
            }
            System.out.println(Thread.currentThread().getName() + "'s balance is $" + balance);
        }
    }
    
    private static class WithdrawRunnable implements Runnable {
        private BankAccount account;
        
        public WithdrawRunnable(BankAccount account) {
            this.account = account;
        }
        
        @Override
        public void run() {
            for (int i = 1; i <= 6; i++) {
                account.withdraw(400);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
}