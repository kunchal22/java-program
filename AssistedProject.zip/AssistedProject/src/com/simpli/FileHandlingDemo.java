package com.simpli;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileHandlingDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String fileName = "test.txt";
        String fileContent;

        // Create file
        File file = new File(fileName);
        try {
            if (file.createNewFile()) {
                System.out.println("File created successfully.");
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("Error occurred while creating file.");
            e.printStackTrace();
        }

        // Write to file
        System.out.print("Enter content to write to file: ");
        fileContent = scanner.nextLine();
        try {
            FileWriter writer = new FileWriter(file);
            writer.write(fileContent);
            writer.close();
            System.out.println("Content written to file successfully.");
        } catch (IOException e) {
            System.out.println("Error occurred while writing to file.");
            e.printStackTrace();
        }

        // Read from file
        System.out.println("Reading file contents:");
        try {
            scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error occurred while reading file.");
            e.printStackTrace();
        }

        // Delete file
        if (file.delete()) {
            System.out.println("File deleted successfully.");
        } else {
            System.out.println("Error occurred while deleting file.");
        }
    }
}
