package com.simpli;
public class MyThread extends Thread
{
 	public void run()
 	{
  		System.out.println(" Thread is  started ");
}
 	public static void main( String args[] )
 	{
  		MyThread t = new  MyThread();
  		t.start();
 	}
}
