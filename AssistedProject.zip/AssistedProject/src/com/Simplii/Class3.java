package com.Simplii;

package com.simpli;

abstract class Class3 {

	abstract public void display3();

	public void display4() {
		System.out.println("Inside display4");
	}

}