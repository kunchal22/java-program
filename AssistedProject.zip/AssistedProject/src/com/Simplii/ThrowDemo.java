package com.Simplii;

//import java.util.Scanner;

public class ThrowDemo {

	public static void main(String[] args) throws Exception {
		// Throw and Throws Demo
		System.out.println("Throw and Throws Demo");
Class1 c1=new Class1();
c1.callme(5);
System.out.println("Program End");
	}
}
class Class1{
	void callme(int x) {
		if(x==5)
			throw new RuntimeException(x + "as Input not accepted");
		else
			System.out.println("Thanku for the input .Accepted");


		
		
		
		//int a=45,b,rs;
//Scanner sc = new Scanner(System.in);
//System.out.println("Type a value of b");

//b=sc.nextInt();
//if(b==0)
		
//throw new ArithmeticException("Can't divide by Zero");
//else
//{
	//rs=a/b;
	//System.out.println("\n\tThe result is:"+rs);

//}

	}
	
	
	

}
