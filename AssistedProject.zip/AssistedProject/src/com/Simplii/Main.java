package com.Simplii;


public class Main {

	public static void main(String[] args) {
		
		// Class1 c1 = new Class1(); WONT WORK
		
		OuterClass outClass1 = new  OuterClass();
		
		OuterClass.Class1 c1 = outClass1.new Class1();
		
		
		// access the inner class's methods
		System.out.println(c1.age);
		c1.display();
		
		c1.displayPriceOfTheOuterClass();
		
		/////////
		
		System.out.println("\n\nDemo another inner class that was defined in a method");
		OuterClass2 outClass2 = new  OuterClass2();
		
		outClass2.display();
		
		//////////Anonymous class
		Class3 c3 = new Class3() {
			
			public void display3() {
				////
			}
		};
		
		c3.display4();// now we can test display4()		

	}

}