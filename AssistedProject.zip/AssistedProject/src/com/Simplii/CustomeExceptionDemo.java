package com.Simplii;



public class CustomeExceptionDemo {

	public static void main(String[] args) {
		System.out.println(" Custom Ex Demo:\n");

		Class4 c4 = new Class4();

		try {
			c4.callMe(15);
			c4.callMe(5);
		} catch (MyException e) {
			System.out.println("Exception happened " + e.getMessage());
		}

		System.out.println("Program End ");
	}

}

class Class4 {

	void callMe(int x) throws MyException {
		if (x == 5)
			throw new MyException(x + " as Input not accepted!");
		else
			System.out.println("Thank you for the input " + x + " accepted");
	}

}
