package com.Simplii;
import java.io.File;
import java.io.*;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;


import java.io.FileWriter;
public class gh {
	public static void main(String[] args) throws Exception {
File f=new File("a2000.txt");
//File f=new File("c:/temp/a2000.txt");

boolean created = f.createNewFile();
if(created)
System.out.println("File is Created");
else
	System.out.println("File is not Created");
//Writing a File
//Writing Content
FileWriter writer = new FileWriter(f);
writer.write("Test Data");
writer.close();
// Approach 2 using FileOutputStream
String data = "Approach 2";
FileOutputStream out = new FileOutputStream("/home/ashokwork1outlo/a2000.txt");
out.write(data.getBytes());
out.close();

//Approach 3 using NIO package
		String data2 = "Test data NIO NIO NIO NIO demo";
		
     Files.write(Paths.get("/home/ashokwork1outlo/a2000.txt"), data2.getBytes());
  // Read a file
     List<String> lines = 
     		Files.readAllLines(Paths.get("/home/ashokwork1outlo/a2000.txt"), StandardCharsets.UTF_8); 
  
     System.out.println("Read the following lines from the file");
     for(String line: lines) {
     	System.out.println(line);
     }


}}

