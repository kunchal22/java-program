package standard_test;

public class DemoClass {

	public int sum(int i, int j) {
		return i+j;
	}
}
