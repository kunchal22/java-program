package com.railway;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.taglibs.standard.tag.el.fmt.RequestEncodingTag;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

@WebServlet("/update")
public class UpdateFetchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public UpdateFetchServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		CrossingModel cm = new CrossingModel();
		cm = session.load(CrossingModel.class,id);
		request.setAttribute("cm", cm);
		request.getRequestDispatcher("/update_crossing.jsp").forward(request,response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
