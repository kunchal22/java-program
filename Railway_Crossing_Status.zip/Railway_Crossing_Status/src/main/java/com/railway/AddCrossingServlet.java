package com.railway;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

@WebServlet("/addcrossing")
public class AddCrossingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public AddCrossingServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cname = request.getParameter("cname");
		String address = request.getParameter("address");
		String landmark = request.getParameter("landmark");
		String trainSchedules = request.getParameter("trainschedules");
		String incharge = request.getParameter("incharge");
		String status = request.getParameter("status");
		
		SessionFactory factory = HibernateUtil.getSessionFactory();
		
		Session session = factory.openSession();
		
		Transaction tx = session.beginTransaction();
		
		CrossingModel cm = new CrossingModel(cname, address, landmark, trainSchedules, incharge, status);
		
		session.save(cm);
		
		tx.commit();
		
		session.close();
		
		response.sendRedirect("admin_dashboard");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
