package com.railway;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

@WebServlet("/updatecrossing")
public class UpdateSaveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public UpdateSaveServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("cid"));
		String name = request.getParameter("cname");
		String address = request.getParameter("address");
		String landmark = request.getParameter("landmark");
		String trainSchedules = request.getParameter("trainschedules");
		String personIncharge = request.getParameter("incharge");
		String status = request.getParameter("status");
		
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		CrossingModel cm = new CrossingModel(id, name, address, landmark, trainSchedules, personIncharge, status);
		session.update(cm);
		tx.commit();
		session.close();
		
		response.sendRedirect("admin_dashboard");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
