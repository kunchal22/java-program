package com.railway;

public class CrossingModel {

	private int cmid;
	private String cname;
	private String address;
	private String landmark;
	private String trainSchedules;
	private String inchargeName;
	private String status;
	
	public CrossingModel() {}

	public CrossingModel(String name, String address, String landmark, String trainSchedules, String inchargeName,
			String status) {
		this.cname = name;
		this.address = address;
		this.landmark = landmark;
		this.trainSchedules = trainSchedules;
		this.inchargeName = inchargeName;
		this.status = status;
	}

	public CrossingModel(int cmid, String name, String address, String landmark, String trainSchedules,
			String inchargeName, String status) {
		this.cmid = cmid;
		this.cname = name;
		this.address = address;
		this.landmark = landmark;
		this.trainSchedules = trainSchedules;
		this.inchargeName = inchargeName;
		this.status = status;
	}

	public int getCmid() {
		return cmid;
	}

	public void setCmid(int cmid) {
		this.cmid = cmid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String name) {
		this.cname = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getTrainSchedules() {
		return trainSchedules;
	}

	public void setTrainSchedules(String trainSchedules) {
		this.trainSchedules = trainSchedules;
	}

	public String getInchargeName() {
		return inchargeName;
	}

	public void setInchargeName(String inchargeName) {
		this.inchargeName = inchargeName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "CrossingModel [cmid=" + cmid + ", name=" + cname + ", address=" + address + ", landmark=" + landmark
				+ ", trainSchedules=" + trainSchedules + ", inchargeName=" + inchargeName + ", status=" + status + "]";
	}
	
}
