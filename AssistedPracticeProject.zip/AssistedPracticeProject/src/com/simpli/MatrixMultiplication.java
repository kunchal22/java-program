package com.simpli;

public class MatrixMultiplication {
    public static void main(String[] args) {
        int[][] matrix1 = { {16, 25, 3}, {44, 45, 46}, {77, 58, 89} };
        int[][] matrix2 = { {10, 11, 12}, {13, 14, 15}, {16, 17, 18} };

        int[][] result = multiplyMatrices(matrix1, matrix2);

        System.out.println("Matrix Multiplication Result:");
        printMatrix(result);
    }

    public static int[][] multiplyMatrices(int[][] matrix1, int[][] matrix2) {
        int m1Rows = matrix1.length;
        int m1Cols = matrix1[0].length;
        int m2Cols = matrix2[0].length;

        if (matrix2.length != m1Cols) {
            throw new IllegalArgumentException("Invalid matrices: Incompatible dimensions");
        }

        int[][] result = new int[m1Rows][m2Cols];

        for (int i = 0; i < m1Rows; i++) {
            for (int j = 0; j < m2Cols; j++) {
                int sum = 0;
                for (int k = 0; k < m1Cols; k++) {
                    sum += matrix1[i][k] * matrix2[k][j];
                }
                result[i][j] = sum;
            }
        }

        return result;
    }

    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int element : row) {
                System.out.print(element + " ");
            }
            System.out.println();
        }
    }
}
