package com.simpli;

public class DoublyLinkedListTraversal {
    static class Node {
        int data;
        Node prev;
        Node next;

        Node(int data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }

    static void traverseForward(Node head) {
        if (head == null) {
            System.out.println("Doubly linked list is empty.");
            return;
        }

        System.out.println("Traversal in forward direction:");
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    static void traverseBackward(Node tail) {
        if (tail == null) {
            System.out.println("Doubly linked list is empty.");
            return;
        }

        System.out.println("Traversal in backward direction:");
        Node current = tail;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node head = new Node(41);
        Node second = new Node(32);
        Node third = new Node(135);
        Node fourth = new Node(141);

        head.next = second;
        second.prev = head;
        second.next = third;
        third.prev = second;
        third.next = fourth;
        fourth.prev = third;

        traverseForward(head);
        traverseBackward(fourth);
    }
}
