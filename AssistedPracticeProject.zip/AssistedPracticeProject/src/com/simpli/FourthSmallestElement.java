package com.simpli;

import java.util.Arrays;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] nums = {66,234,777,8899,63663,292900288,3434,2222,6789,897654};

        int fourthSmallest = findFourthSmallestElement(nums);
        System.out.println("Fourth smallest element: " + fourthSmallest);
    }

    public static int findFourthSmallestElement(int[] nums) {
        if (nums == null || nums.length < 4) {
            throw new IllegalArgumentException("Invalid input: At least 4 elements are required");
        }

        // Sort the array in ascending order
        Arrays.sort(nums);

        // Return the fourth element (at index 3) from the sorted array
        return nums[3];
    }
}
