package com.simpli;

import java.util.LinkedList;
import java.util.Queue;

public class QueueOperations {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        // Inserting elements into the queue
        queue.offer(1098);
        queue.offer(2009);
        queue.offer(300);
        queue.offer(470);

        System.out.println("Queue elements after insertion: " + queue);

        // Removing elements from the queue
        int removedElement = queue.poll();
        System.out.println("Removed element from queue: " + removedElement);

        System.out.println("Queue elements after removal: " + queue);

        // Accessing the front element of the queue
        int frontElement = queue.peek();
        System.out.println("Front element of queue: " + frontElement);
    }
}