package com.simpli;

public class CircularLinkedListInsertion {
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    static Node insert(Node head, int newValue) {
        Node newNode = new Node(newValue);

        if (head == null) {
            newNode.next = newNode;
            return newNode;
        }

        Node current = head;

        // Check if the new value should be inserted at the beginning
        if (newValue < head.data) {
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            return newNode;
        }

        // Find the correct position to insert the new value
        while (current.next != head && current.next.data < newValue) {
            current = current.next;
        }

        newNode.next = current.next;
        current.next = newNode;
        return head;
    }

    static void displayCircularLinkedList(Node head) {
        if (head == null) {
            System.out.println("Circular linked list is empty.");
            return;
        }

        Node current = head;

        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);

        System.out.println();
    }

    public static void main(String[] args) {
        Node head = new Node(298);
        Node second = new Node(498);
        Node third = new Node(676);
        Node fourth = new Node(809);

        head.next = second;
        second.next = third;
        third.next = fourth;
        fourth.next = head;

        System.out.println("Circular Linked List before insertion:");
        displayCircularLinkedList(head);

        int newValue = 7655;
        head = insert(head, newValue);

        System.out.println("Circular Linked List after inserting " + newValue + ":");
        displayCircularLinkedList(head);
    }
}