package com.simpli;

public class SumInRange {
    public static void main(String[] args) {
        int[] nums = {23,76,99,78,56,88,97,55};
        int n = nums.length;
        int L = 2; // Starting index of the range
        int R = 5; // Ending index of the range

        int sum = findSumInRange(nums, n, L, R);
        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);
    }

    public static int findSumInRange(int[] nums, int n, int L, int R) {
        if (nums == null || n == 0 || L > R || L < 0 || R >= n) {
            throw new IllegalArgumentException("Invalid input");
        }

        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += nums[i];
        }
        return sum;
    }
}
