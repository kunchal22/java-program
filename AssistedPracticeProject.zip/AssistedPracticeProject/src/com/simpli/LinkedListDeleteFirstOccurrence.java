package com.simpli;

public class LinkedListDeleteFirstOccurrence {
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    static Node deleteFirstOccurrence(Node head, int key) {
        if (head == null) {
            return null;
        }

        if (head.data == key) {
            return head.next;
        }

        Node prev = head;
        Node curr = head.next;

        while (curr != null) {
            if (curr.data == key) {
                prev.next = curr.next;
                break;
            }
            prev = curr;
            curr = curr.next;
        }

        return head;
    }

    static void displayLinkedList(Node head) {
        if (head == null) {
            System.out.println("Linked list is empty.");
            return;
        }

        Node curr = head;
        while (curr != null) {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Node head = new Node(901);
        Node second = new Node(42);
        Node third = new Node(13);
        Node fourth = new Node(94);
        Node fifth = new Node(35);

        head.next = second;
        second.next = third;
        third.next = fourth;
        fourth.next = fifth;

        System.out.println("Linked List before deletion:");
        displayLinkedList(head);

        int key = 35;
        head = deleteFirstOccurrence(head, key);

        System.out.println("Linked List after deleting first occurrence of " + key + ":");
        displayLinkedList(head);
    }
}