package com.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
@ComponentScan({"com.ecommerce.controller", "com.ecommerce.entity","com.ecommerce.repository", "com.ecommerce.service" })

@SpringBootApplication
public class VaccinationCentreApplication {

	public static void main(String[] args) {
		SpringApplication.run(VaccinationCentreApplication.class, args);
	}

}
